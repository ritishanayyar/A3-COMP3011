/*
 * Starter code supplied for Adelaide University COMP3011 Assignment 2.
 * Students are free to modify this file for assessment purposes.
 *
 * Authors:
 *   1. Simon Ratcliffe, in collaboration with GPT-5.6 Terra
 *   2. Ritisha Nayyar, a1948388
 * Copyright 2026 Simon Ratcliffe
 */
package comp3011;

import java.io.File;
import java.util.List;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.function.BiConsumer;
import java.util.function.Consumer;

import org.bytedeco.javacv.FFmpegFrameGrabber;
import org.bytedeco.javacv.Frame;
import org.bytedeco.javacv.FrameGrabber;

import javafx.animation.AnimationTimer;
import javafx.scene.image.Image;

/**
 * The model part of the video player model-view-controller architecture.
 *
 * <p>
 * Owns the FFmpeg decoder, playback clock, seeking logic, audio scheduling,
 * and frame processing - which it all manages through decoding, effects, 
 * and conversion on multiple threads. It publishes decoded frames and playback state through
 * callbacks supplied by its owning {@link VideoPlayerController}, keeping it
 * decoupled from the JavaFX view.
 * </p>
 */
public class VideoPlayerModel {
    private static final long NO_SEEK_REQUEST = -1; // Sentinel value used when no seek position is active.
    private static final long FIVE_SECONDS_US = 5_000_000L;
    private static final long AUDIO_LEAD_NS = 30_000_000L;

    // If a frame is displayed more than this late, move the playback clock forward so that playback slows down
    // smoothly rather than racing to catch up.
    private static final long MAX_LATENESS_BEFORE_RESYNC_NS = 20_000_000L;

    private final List<String> frameEffects; // Effect letters from the command line, turned into chains by the pipeline.
    private final Queue<PendingAudio> pendingAudio = new ConcurrentLinkedQueue<>(); // Decoder thread adds, JavaFX thread drains.
    private final BiConsumer<Integer, Integer> videoSizeChangedHandler;
    private final Consumer<Image> frameReadyHandler;
    private final Consumer<String> statusChangedHandler;
    private final BiConsumer<Boolean, Boolean> playbackStateChangedHandler;
    private final Consumer<Boolean> audioOutputStateChangedHandler;
    private final Consumer<String> subtitleChangedHandler;
    private final SubtitleService subtitleService = new SubtitleService();
    private List<SubtitleService.SubtitleSegment> subtitleSegments = List.of();
    private boolean subtitlesEnabled;
    private boolean subtitleTranscriptionStarted;
    private String currentSubtitleText = "";   

    // This is the critical wiring that allows the framework (JavaFX) to call
    // into our model logic every time it goes around its event loop. Every GUI
    // system has an event loop so that button clicks, key presses and window
    // resizes can be responded to. Most offer ways of running additional logic
    // in either idle time (when there are no pending UI events to process) or
    // on a regular heart beat, such as with this JavaFX AnimationTimer. Here
    // we just create a little anonymous local subclass and override the handle
    // method to call the method we want run every heart beat.
    private final AnimationTimer playbackTimer = new AnimationTimer() {
        @Override
        public void handle(long now) {
            pumpPlayback(now);
        }
    };
    private File videoFile; // Path to the media that comes from the command line
    private FFmpegFrameGrabber grabber; // This is the 3rd party video media decoder. It deals in JavaCV Frame objects.
    private AudioPlayer audioPlayer; // This is ours. It has some real time buffering smarts.
    private FramePipeline pipeline; // Decoder thread plus worker threads. Created when a video is opened.
    private boolean playbackOpen; // True when playback is happening.
    private boolean pauseRequested;
    private volatile boolean audioOutputEnabled;
    private boolean audioAvailable;
    private long currentTimestampUs;
    private long videoDurationUs = NO_SEEK_REQUEST;
    private int videoFrameDurationUs;
    private double frameRate;
    private int intFrameRate;
    private int totalVideoFrames;
    private long firstTimestampUs = NO_SEEK_REQUEST;
    private long logicalPlaybackBaseUs;
    private long playbackStartNs;
    private long pauseStartedNs;
    private long relativeSeekBaseUs = NO_SEEK_REQUEST;

    public VideoPlayerModel(
            boolean audioEnabled,
            boolean subtitleEnabled,
            Consumer<String> subtitleChangedHandler,
            List<String> frameEffects,
            BiConsumer<Integer, Integer> videoSizeChangedHandler,
            Consumer<Image> frameReadyHandler,
            Consumer<String> statusChangedHandler,
            BiConsumer<Boolean, Boolean> playbackStateChangedHandler,
            Consumer<Boolean> audioOutputStateChangedHandler) {
        audioOutputEnabled = audioEnabled;
        subtitlesEnabled = subtitleEnabled;
        this.subtitleChangedHandler = subtitleChangedHandler;
        this.frameEffects = List.copyOf(frameEffects);
        this.videoSizeChangedHandler = videoSizeChangedHandler;
        this.frameReadyHandler = frameReadyHandler;
        this.statusChangedHandler = statusChangedHandler;
        this.playbackStateChangedHandler = playbackStateChangedHandler;
        this.audioOutputStateChangedHandler = audioOutputStateChangedHandler;
    }
    public void play(File file) {
       videoFile = file;
       videoDurationUs = NO_SEEK_REQUEST;
       videoFrameDurationUs = 0;

       subtitleSegments = List.of();
       subtitleTranscriptionStarted = false;
       currentSubtitleText = "";
       subtitleChangedHandler.accept("");

       startPlayback(0, false, NO_SEEK_REQUEST);
       if (subtitlesEnabled) {
        startSubtitleTranscription();
    }
}

    public void startOver() {
        if (videoFile == null) {
            return;
        }

        seekTo(0);
    }
    public void backFiveSeconds() {
        seekRelative(-FIVE_SECONDS_US);
    }

    public void forwardFiveSeconds() {
        seekRelative(FIVE_SECONDS_US);
    }

    public void togglePause() {
        if (!playbackOpen) {
            if (videoFile != null) {
                startPlayback(displayableSeekTimestamp(currentTimestampUs), false, currentTimestampUs);
            }
            return;
        }

        pauseRequested = !pauseRequested;
        relativeSeekBaseUs = NO_SEEK_REQUEST;

        if (pauseRequested) {
            pauseStartedNs = System.nanoTime();
            flushAudioOutput();
        } else {
            resumePlaybackClock(System.nanoTime());
        }

        notifyPlaybackStateChanged();
    }

    public void toggleSubtitles() {
    subtitlesEnabled = !subtitlesEnabled;

    if (!subtitlesEnabled) {
        currentSubtitleText = "";
        subtitleChangedHandler.accept("");
    } else {
        if (!subtitleTranscriptionStarted) {
            startSubtitleTranscription();
        }
        updateSubtitle(currentTimestampUs);
    }
}

private void startSubtitleTranscription() {
    if (videoFile == null || subtitleTranscriptionStarted) {
        return;
    }

    subtitleTranscriptionStarted = true;
    File requestedFile = videoFile;

    subtitleService.transcribe(requestedFile, segments -> {
        javafx.application.Platform.runLater(() -> {
            if (videoFile != requestedFile) {
                return;
            }

            subtitleSegments = segments;
            updateSubtitle(currentTimestampUs);
        });
    });
}

private void updateSubtitle(long timestampUs) {
    String text = "";

    if (subtitlesEnabled) {
        double seconds = timestampUs / 1_000_000.0;

        for (SubtitleService.SubtitleSegment segment : subtitleSegments) {
            if (seconds >= segment.start() && seconds <= segment.end()) {
                text = segment.text();
                break;
            }
        }
    }

    if (!text.equals(currentSubtitleText)) {
        currentSubtitleText = text;
        subtitleChangedHandler.accept(text);
    }
}

public boolean isAudioOutputEnabled() {
    return audioOutputEnabled;
}

public void toggleAudioOutput() {
    audioOutputEnabled = !audioOutputEnabled;
    if (!audioOutputEnabled) {
        flushAudioOutput();
    }
    notifyAudioOutputStateChanged();
}


    public void stopPlayback() {
        closePlaybackResources();
        currentTimestampUs = 0;
        pauseRequested = false;
        notifyStatusChanged("Stopped");
        notifyFrameReady(null);
        notifyPlaybackStateChanged();
    }

    public void shutdown() {
        closePlaybackResources();
    }

    private void seekRelative(long offsetUs) {
        if (videoFile == null) {
            return;
        }

        long baseTimestampUs = relativeSeekBaseUs != NO_SEEK_REQUEST
                ? relativeSeekBaseUs
                : currentTimestampUs;
        seekTo(baseTimestampUs + offsetUs);
    }

    private void seekTo(long timestampUs) {
        long logicalTimestampUs = clampSeekTimestamp(timestampUs);
        long grabTimestampUs = displayableSeekTimestamp(logicalTimestampUs);

        if (!playbackOpen) {
            startPlayback(grabTimestampUs, pauseRequested, logicalTimestampUs);
            return;
        }

        try {
            // The grabber belongs to the decoder thread while the pipeline is running so the pipeline has to be stopped 
            pipeline.stop();
            grabber.setTimestamp(grabTimestampUs);
            resetPlaybackClock(logicalTimestampUs);
            flushAudioOutput();
            pipeline.start();
            notifyPlaybackStateChanged();
        } catch (Exception e) {
            handlePlaybackError(e);
        }
    }

    private void startPlayback(long startTimestampUs, boolean initiallyPaused, long initialRelativeSeekBaseUs) {
        closePlaybackResources();

        pauseRequested = initiallyPaused;
        currentTimestampUs = initialRelativeSeekBaseUs != NO_SEEK_REQUEST
                ? initialRelativeSeekBaseUs
                : startTimestampUs;
        relativeSeekBaseUs = initialRelativeSeekBaseUs;

        notifyStatusChanged(videoFile.getName());

        try {
            openPlaybackResources(startTimestampUs);
            resetPlaybackClock(currentTimestampUs);
            playbackOpen = true;
            playbackTimer.start();
            pipeline.start();
            notifyPlaybackStateChanged();
        } catch (Exception e) {
            handlePlaybackError(e);
        }
    }

    private void openPlaybackResources(long startTimestampUs) throws Exception {
        grabber = new FFmpegFrameGrabber(videoFile);
        grabber.setImageMode(FrameGrabber.ImageMode.COLOR);
        grabber.setSampleMode(FrameGrabber.SampleMode.SHORT);
        grabber.start();

        notifyVideoSizeChanged(grabber.getImageWidth(), grabber.getImageHeight());

        frameRate = grabber.getFrameRate();
        intFrameRate = (int) Math.round(frameRate);
        videoFrameDurationUs = frameRate > 0
                ? (int) Math.round(1_000_000.0 / frameRate)
                : 0;
        totalVideoFrames = grabber.getLengthInVideoFrames();

        long durationUs = grabber.getLengthInTime();
        videoDurationUs = durationUs > 0
                ? durationUs
                : NO_SEEK_REQUEST;

        audioAvailable = grabber.hasAudio();
        audioPlayer = new AudioPlayer();
        if (audioAvailable) {
            audioPlayer.open(grabber.getSampleRate(), grabber.getAudioChannels());
        }

        // The pipeline builds one private chain of effects per worker thread. The two method references are the
        // only places it calls back into this class, both from its decoder thread.
        pipeline = new FramePipeline(
                grabber,
                audioAvailable,
                frameEffects,
                FramePipeline.DEFAULT_WORKER_COUNT,
                this::queueAudio,
                this::describeVideo,
                this::handlePlaybackError);

        if (startTimestampUs > 0) {
            grabber.setTimestamp(startTimestampUs);
        }
    }

    private void resetPlaybackClock(long logicalTimestampUs) {
        pendingAudio.clear();
        currentTimestampUs = logicalTimestampUs;
        relativeSeekBaseUs = logicalTimestampUs;
        firstTimestampUs = NO_SEEK_REQUEST;
        logicalPlaybackBaseUs = logicalTimestampUs;
        playbackStartNs = 0;
        pauseStartedNs = pauseRequested ? System.nanoTime() : 0;
    }

    private void resumePlaybackClock(long now) {
        if (pauseStartedNs > 0 && playbackStartNs > 0) {
            playbackStartNs += now - pauseStartedNs;
        }
        pauseStartedNs = 0;
    }
    private void startPlaybackClock(long firstFrameTimestampUs) {
        firstTimestampUs = firstFrameTimestampUs;
        playbackStartNs = System.nanoTime();
        if (pauseRequested) {
            pauseStartedNs = playbackStartNs;
        }
    }

    // This is called on a heart beat by the GUI thread. Decoding and effects now happen on other threads, so all this
    // has to do is two quick jobs: (1) keep audio flowing if sound is on, and (2) display the next finished frame if
    // it is due. Frames always come out of the pipeline in order, even though the workers finish them out of order.
    private void pumpPlayback(long now) {
        if (!playbackOpen || pipeline == null) {
            return;
        }

        // Task (1)
        writeDueAudio(now);

        // Task (2)
        FramePipeline.PreparedFrame next = pipeline.peekNext();
        if (next == null) {
            // Nothing ready. Either the workers are behind, or we have shown every frame in the media.
            if (pipeline.isDrained() && !pauseRequested) {
                finishPlayback();
            }
            return;
        }

        if (firstTimestampUs == NO_SEEK_REQUEST) {
            startPlaybackClock(next.mediaTimestampUs()); // First frame after a start or seek: show it straight away.
        } else if (pauseRequested) {
            return; // Keep showing the current frame.
        }

        long relativeTimestampUs = Math.max(0, next.mediaTimestampUs() - firstTimestampUs);
        long targetTimeNs = playbackStartNs + relativeTimestampUs * 1_000L;
        if (targetTimeNs <= now) {
            pipeline.advance(); // Frees a slot so the decoder can admit one more frame.
            displayPreparedFrame(next, logicalPlaybackBaseUs + relativeTimestampUs, targetTimeNs);

            long latenessNs = now - targetTimeNs;
            if (latenessNs > MAX_LATENESS_BEFORE_RESYNC_NS) {
                playbackStartNs += latenessNs;
            }
        }
    }

    private void displayPreparedFrame(FramePipeline.PreparedFrame frame, long logicalTimestampUs, long targetTimeNs) {
        currentTimestampUs = logicalTimestampUs;
        updateSubtitle(logicalTimestampUs);
        relativeSeekBaseUs = NO_SEEK_REQUEST;

        // Dump some logging to the console once per second so that real time performance can be monitored.
        if (intFrameRate > 0 && frame.frameNumber() % intFrameRate == 0) {
            long remainingUs = (targetTimeNs - frame.preparedAtNs()) / 1_000L;
            if (remainingUs < 0) {
                System.out.printf("Frame headroom is \u001B[31m%5dus\u001B[0m out of %dus spare.%n",
                        remainingUs,
                        videoFrameDurationUs);
            } else {
                System.out.printf("Frame headroom is \u001B[32m%5dus\u001B[0m out of %dus spare.%n",
                        remainingUs,
                        videoFrameDurationUs);
            }
        }

        notifyFrameReady(frame.image());
    }

    // Called by the pipeline on its decoder thread. 
    private void queueAudio(long timestampUs, Frame frame) {
        if (!audioOutputEnabled || audioPlayer == null) {
            return;
        }

        byte[] samples = audioPlayer.copySamples(frame);
        if (samples.length > 0) {
            pendingAudio.add(new PendingAudio(timestampUs, samples));
        }
    }

    private void writeDueAudio(long now) {
        // Handle some obvious early exits
        if (!audioOutputEnabled || audioPlayer == null) {
            pendingAudio.clear();
            return;
        }
        if (pauseRequested || firstTimestampUs == NO_SEEK_REQUEST || playbackStartNs <= 0) {
            return;
        }

        // the real time dependent logic
        long dueTimestampUs = firstTimestampUs + (now + AUDIO_LEAD_NS - playbackStartNs) / 1_000L;
        while (!pendingAudio.isEmpty()) {
            PendingAudio audio = pendingAudio.peek();
            if (audio.timestampUs() > dueTimestampUs) {
                return;
            }

            int written = audioPlayer.write(audio.samples(), audio.offset(), audio.remaining());
            if (written <= 0) {
                return;
            }

            audio.advance(written);
            if (!audio.finished()) {
                return;
            }
            pendingAudio.remove();
        }
    }

    private void finishPlayback() {
        long endTimestampUs = videoDurationUs != NO_SEEK_REQUEST
                ? videoDurationUs
                : currentTimestampUs;

        closePlaybackResources();
        pauseRequested = true;
        currentTimestampUs = endTimestampUs;
        relativeSeekBaseUs = endTimestampUs;
        notifyStatusChanged("Playback finished");
        notifyPlaybackStateChanged();
    }

    private void handlePlaybackError(Exception e) {
        e.printStackTrace();
        closePlaybackResources();
        pauseRequested = false;
        notifyStatusChanged("Error: " + e.getMessage());
        notifyPlaybackStateChanged();
    }

    private void closePlaybackResources() {
        playbackTimer.stop();
        playbackOpen = false;

        // The pipeline must be stopped (threads joined) before the grabber is closed below, otherwise the decoder
        // thread could still be reading from a closed grabber.
        if (pipeline != null) {
            pipeline.stop();
            pipeline = null;
        }

        pendingAudio.clear();
        firstTimestampUs = NO_SEEK_REQUEST;
        playbackStartNs = 0;
        pauseStartedNs = 0;
        audioAvailable = false;

        if (audioPlayer != null) {
            audioPlayer.close();
            audioPlayer = null;
        }

        if (grabber != null) {
            try {
                grabber.stop();
            } catch (Exception e) {
                // The resource is being closed; there is no useful recovery action.
            }
            try {
                grabber.close();
            } catch (Exception e) {
                // The resource is being closed; there is no useful recovery action.
            }
            grabber = null;
        }
    }

    // Called by the pipeline once per run, on its decoder thread, when the first video frame arrives. It reads
    // fields that were written on the JavaFX thread before the pipeline was started, so no locking is needed.
    private InfoVideo describeVideo(Frame frame) {
        return new InfoVideo(
                mediaName(videoFile),
                totalVideoFrames,
                frame.imageWidth,
                frame.imageHeight,
                frame.imageDepth,
                frame.imageChannels,
                frame.imageStride,
                frameRate,
                intFrameRate,
                videoFrameDurationUs,
                grabber.getPixelFormat());
    }

    private String mediaName(File file) {
        String fileName = file.getName();
        int extensionStart = fileName.lastIndexOf('.');
        if (extensionStart <= 0) {
            return fileName;
        }
        return fileName.substring(0, extensionStart);
    }

    private long clampSeekTimestamp(long timestampUs) {
        long clampedTimestampUs = Math.max(0, timestampUs);
        long durationUs = videoDurationUs;
        if (durationUs != NO_SEEK_REQUEST) {
            clampedTimestampUs = Math.min(clampedTimestampUs, durationUs);
        }
        return clampedTimestampUs;
    }

    private long displayableSeekTimestamp(long logicalTimestampUs) {
        long durationUs = videoDurationUs;
        if (durationUs == NO_SEEK_REQUEST || logicalTimestampUs < durationUs) {
            return logicalTimestampUs;
        }

        int frameDurationUs = videoFrameDurationUs;
        if (frameDurationUs <= 0) {
            return Math.max(0, durationUs - 1);
        }

        return Math.max(0, durationUs - frameDurationUs);
    }

    private void flushAudioOutput() {
        if (audioPlayer != null) {
            audioPlayer.flush();
        }
    }

    private void notifyVideoSizeChanged(int width, int height) {
        videoSizeChangedHandler.accept(width, height);
    }

    private void notifyFrameReady(Image image) {
        frameReadyHandler.accept(image);
    }

    private void notifyStatusChanged(String status) {
        statusChangedHandler.accept(status);
    }

    private void notifyPlaybackStateChanged() {
        playbackStateChangedHandler.accept(playbackOpen, pauseRequested);
    }

    private void notifyAudioOutputStateChanged() {
        audioOutputStateChangedHandler.accept(audioOutputEnabled);
    }

    private static class PendingAudio {
        private final long timestampUs;
        private final byte[] samples;
        private int offset;

        PendingAudio(long timestampUs, byte[] samples) {
            this.timestampUs = timestampUs;
            this.samples = samples;
        }

        long timestampUs() {
            return timestampUs;
        }

        byte[] samples() {
            return samples;
        }

        int offset() {
            return offset;
        }
        int remaining() {
            return samples.length - offset;
        }
        void advance(int byteCount) {
            offset+= byteCount;
        }

        boolean finished() {
            return offset >= samples.length;
        }
    }
}