package com.example.assignment1.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Stream;

@Component
public class OpenAiSpeechToTextClient implements SpeechToTextClient {

    private static final Logger log =
            LoggerFactory.getLogger(OpenAiSpeechToTextClient.class);

    private static final String DEFAULT_MODEL =
            System.getProperty("user.home") + "/whisper-models/ggml-base.en.bin";

    private static final Pattern TIMESTAMP_PATTERN = Pattern.compile(
            "(\\d{2}:\\d{2}:\\d{2}[,.]\\d{3})\\s*-->\\s*" +
            "(\\d{2}:\\d{2}:\\d{2}[,.]\\d{3})"
    );

    @Override
    public TranscriptionResult transcribe(
            byte[] audioBytes,
            String filename
    ) throws Exception {

        if (audioBytes == null || audioBytes.length == 0) {
            throw new IllegalArgumentException("Audio file is empty");
        }

        String modelSetting = System.getenv("WHISPER_MODEL");
        Path model = Path.of(
                modelSetting == null || modelSetting.isBlank()
                        ? DEFAULT_MODEL
                        : modelSetting
        );

        if (!Files.isRegularFile(model)) {
            throw new IOException("Whisper model not found: " + model);
        }

        String executable = System.getenv("WHISPER_CLI");
        if (executable == null || executable.isBlank()) {
            executable = "whisper-cli";
        }

        Path tempDir = Files.createTempDirectory("local-whisper-");

        try {
            Path audioFile = tempDir.resolve("audio.wav");
            Path outputPrefix = tempDir.resolve("transcription");
            Path logFile = tempDir.resolve("whisper.log");
            Path subtitleFile = tempDir.resolve("transcription.srt");

            Files.write(audioFile, audioBytes);

            ProcessBuilder builder = new ProcessBuilder(
                    executable,
                    "-m", model.toString(),
                    "-f", audioFile.toString(),
                    "-osrt",
                    "-of", outputPrefix.toString(),
                    "-l", "en",
                    "-t", "4",
                    "-np"
            );

            builder.redirectErrorStream(true);
            builder.redirectOutput(logFile.toFile());

            log.info("Starting local Whisper transcription");

            Process process;

            try {
                process = builder.start();
            } catch (IOException e) {
                throw new IOException(
                        "Could not start whisper-cli. Check that whisper.cpp is installed.",
                        e
                );
            }

            boolean completed = process.waitFor(15, TimeUnit.MINUTES);

            if (!completed) {
                process.destroyForcibly();
                throw new IOException("Local Whisper transcription timed out");
            }

            String processOutput = Files.exists(logFile)
                    ? Files.readString(logFile)
                    : "";

            if (process.exitValue() != 0) {
                throw new IOException(
                        "Whisper failed: " + processOutput
                );
            }

            if (!Files.isRegularFile(subtitleFile)) {
                throw new IOException(
                        "Whisper did not create an SRT file. " + processOutput
                );
            }

            List<TranscriptionResult.SubtitleSegment> segments =
                    parseSubtitles(Files.readString(subtitleFile));

            String text = segments.stream()
                    .map(TranscriptionResult.SubtitleSegment::text)
                    .reduce((a, b) -> a + " " + b)
                    .orElse("");

            double duration = segments.stream()
                    .mapToDouble(TranscriptionResult.SubtitleSegment::end)
                    .max()
                    .orElse(0.0);

            log.info(
                    "Local Whisper completed. Segments: {}, duration: {} seconds",
                    segments.size(),
                    duration
            );

            return new TranscriptionResult(
                    text,
                    segments,
                    duration,
                    0,
                    0
            );

        } finally {
            deleteTemporaryFiles(tempDir);
        }
    }

    private List<TranscriptionResult.SubtitleSegment> parseSubtitles(
            String srt
    ) {

        List<TranscriptionResult.SubtitleSegment> segments =
                new ArrayList<>();

        String[] blocks = srt.split("\\R\\s*\\R");

        for (String block : blocks) {

            Matcher matcher = TIMESTAMP_PATTERN.matcher(block);

            if (!matcher.find()) {
                continue;
            }

            int lineEnd = block.indexOf('\n', matcher.end());

            if (lineEnd < 0) {
                continue;
            }

            String subtitleText = block.substring(lineEnd + 1)
                    .replace("\r", "")
                    .strip()
                    .replaceAll("\\s+", " ");

            if (subtitleText.isBlank()) {
                continue;
            }

            double start = parseTimestamp(matcher.group(1));
            double end = parseTimestamp(matcher.group(2));

            segments.add(
                    new TranscriptionResult.SubtitleSegment(
                            start,
                            end,
                            subtitleText,
                            0.0,
                            0.0
                    )
            );
        }

        return segments;
    }

    private double parseTimestamp(String timestamp) {

        String[] parts = timestamp.replace(',', '.').split(":");

        double hours = Double.parseDouble(parts[0]);
        double minutes = Double.parseDouble(parts[1]);
        double seconds = Double.parseDouble(parts[2]);

        return hours * 3600 + minutes * 60 + seconds;
    }

    private void deleteTemporaryFiles(Path directory) {

        try (Stream<Path> paths = Files.walk(directory)) {

            paths.sorted(Comparator.reverseOrder())
                    .forEach(path -> {
                        try {
                            Files.deleteIfExists(path);
                        } catch (IOException e) {
                            log.warn("Could not delete temporary file: {}", path);
                        }
                    });

        } catch (IOException e) {
            log.warn("Could not clean temporary Whisper directory", e);
        }
    }
}
